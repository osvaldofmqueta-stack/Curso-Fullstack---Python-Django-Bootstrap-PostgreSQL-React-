export async function listarProdutos() {
  const response = await fetch("/api/produtos/");
  if (!response.ok) throw new Error("Erro na API");
  return response.json();
}
