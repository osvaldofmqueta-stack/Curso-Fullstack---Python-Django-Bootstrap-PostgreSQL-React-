# EXPECTED — Aula 19

Este diretório mostra o marco esperado de **integração full-stack**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 19.
