# EXPECTED — Aula 12

Este diretório mostra o marco esperado de **PostgreSQL configurado**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 12.
