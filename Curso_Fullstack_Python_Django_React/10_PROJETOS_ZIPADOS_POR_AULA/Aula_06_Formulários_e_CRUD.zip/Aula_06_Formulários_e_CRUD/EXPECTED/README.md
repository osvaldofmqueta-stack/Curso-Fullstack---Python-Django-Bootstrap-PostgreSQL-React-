# EXPECTED — Aula 06

Este diretório mostra o marco esperado de **CRUD completo**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 6.
