# EXPECTED — Aula 21

Este diretório mostra o marco esperado de **plano do produto**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 21.
