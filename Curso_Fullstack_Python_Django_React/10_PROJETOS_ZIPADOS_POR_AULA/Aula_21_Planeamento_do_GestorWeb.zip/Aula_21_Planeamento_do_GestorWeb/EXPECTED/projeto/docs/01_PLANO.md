# MVP GestorWeb

Problema, utilizadores, funcionalidades e critérios de aceitação.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
