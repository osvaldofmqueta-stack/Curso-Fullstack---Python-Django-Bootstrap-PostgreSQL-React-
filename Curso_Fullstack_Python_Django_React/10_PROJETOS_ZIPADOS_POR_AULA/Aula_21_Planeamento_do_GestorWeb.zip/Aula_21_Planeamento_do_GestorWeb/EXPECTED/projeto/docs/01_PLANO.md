# MVP GestorWeb

Problema, utilizadores, funcionalidades e critérios de aceitação.
