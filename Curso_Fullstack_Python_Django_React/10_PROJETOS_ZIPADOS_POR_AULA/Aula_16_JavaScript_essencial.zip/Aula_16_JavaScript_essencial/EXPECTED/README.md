# EXPECTED — Aula 16

Este diretório mostra o marco esperado de **frontend JavaScript**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 16.
