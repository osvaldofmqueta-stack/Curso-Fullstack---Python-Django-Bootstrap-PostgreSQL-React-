# EXPECTED — Aula 16

Este diretório mostra o marco esperado de **frontend JavaScript**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 16.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
