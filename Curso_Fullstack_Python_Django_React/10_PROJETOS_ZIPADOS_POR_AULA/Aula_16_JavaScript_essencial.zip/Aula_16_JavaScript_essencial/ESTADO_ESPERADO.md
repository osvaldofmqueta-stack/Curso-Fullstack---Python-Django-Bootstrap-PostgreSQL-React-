# Estado esperado — Aula 16

## Marco visual

A aplicação está na fase: **frontend JavaScript**.

## Estrutura mínima

```text
├── frontend/package.json
├── frontend/src/App.jsx
├── frontend/src/api/products.js
├── frontend/src/components/ProductCard.jsx
├── frontend/src/pages/Dashboard.jsx
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
