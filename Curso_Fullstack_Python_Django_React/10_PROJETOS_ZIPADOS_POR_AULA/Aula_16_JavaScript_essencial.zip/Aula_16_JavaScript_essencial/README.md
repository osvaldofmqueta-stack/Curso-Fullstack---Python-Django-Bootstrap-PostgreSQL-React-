# Aula 16 — JavaScript essencial

## O que esta pasta representa

Este ZIP é o kit-guia do estado da aplicação depois da Aula 16. Ele acompanha o curso e mostra o ponto de partida e o resultado esperado.

## Objetivo

Eventos, DOM, fetch, JSON e estados de interface.

## Resultado esperado

Ao terminar, a aplicação deve ter: **frontend JavaScript**.

## Como usar

1. Extrai este ZIP para uma pasta de estudo.
2. Lê `ESTADO_ESPERADO.md` e observa `projeto/`.
3. Começa pelo `STARTER/` se quiseres construir sem solução.
4. Usa `EXPECTED/` apenas para comparar depois da tua tentativa.
5. Executa o checklist e regista os erros.

## Importante

O conteúdo `EXPECTED/` é uma referência didática da estrutura e dos exemplos principais da aula. A implementação deve ser construída por ti seguindo a apostila correspondente.

## Fase

06_FRONTEND_REACT

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
