# Checklist

- [ ] Li a Aula 23 e compreendi o objetivo.
- [ ] Criei ou alterei os ficheiros do projeto.
- [ ] Executei a aplicação ou comando indicado.
- [ ] Comparei o resultado com EXPECTED.
- [ ] Registei pelo menos um erro e a solução.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
