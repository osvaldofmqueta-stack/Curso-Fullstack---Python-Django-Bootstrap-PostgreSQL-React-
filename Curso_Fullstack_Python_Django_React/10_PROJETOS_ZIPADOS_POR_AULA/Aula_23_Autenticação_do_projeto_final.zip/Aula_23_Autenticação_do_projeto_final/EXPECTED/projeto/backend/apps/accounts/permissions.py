PERFIS = ["administrador", "gestor", "operador"]

# mapear grupos Django para permissões do produto
