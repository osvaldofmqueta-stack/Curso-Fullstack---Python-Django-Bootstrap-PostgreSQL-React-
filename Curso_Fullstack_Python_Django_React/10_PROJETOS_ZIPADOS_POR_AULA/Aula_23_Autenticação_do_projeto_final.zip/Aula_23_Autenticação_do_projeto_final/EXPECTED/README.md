# EXPECTED — Aula 23

Este diretório mostra o marco esperado de **acessos por perfil**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 23.
