# EXPECTED — Aula 23

Este diretório mostra o marco esperado de **acessos por perfil**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 23.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
