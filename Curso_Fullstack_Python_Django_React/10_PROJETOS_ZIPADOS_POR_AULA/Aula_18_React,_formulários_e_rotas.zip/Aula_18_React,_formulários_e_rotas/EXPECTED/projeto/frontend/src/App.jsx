import { BrowserRouter, Routes, Route } from "react-router-dom";

export default function App() {
  return <BrowserRouter><Routes>{/* rotas da aula */}</Routes></BrowserRouter>;
}
