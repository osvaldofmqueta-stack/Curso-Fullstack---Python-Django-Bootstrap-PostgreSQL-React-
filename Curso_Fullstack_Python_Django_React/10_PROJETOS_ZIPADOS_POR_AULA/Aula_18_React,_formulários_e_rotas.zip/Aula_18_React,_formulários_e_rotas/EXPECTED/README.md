# EXPECTED — Aula 18

Este diretório mostra o marco esperado de **frontend navegável**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 18.
