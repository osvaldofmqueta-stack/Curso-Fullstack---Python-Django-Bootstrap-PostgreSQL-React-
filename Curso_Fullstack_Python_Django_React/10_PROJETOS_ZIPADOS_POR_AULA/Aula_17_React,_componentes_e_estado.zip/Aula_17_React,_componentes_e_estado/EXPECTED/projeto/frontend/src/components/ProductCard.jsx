export default function ProductCard({ produto }) {
  return <article className="card"><h2>{produto.nome}</h2></article>;
}
