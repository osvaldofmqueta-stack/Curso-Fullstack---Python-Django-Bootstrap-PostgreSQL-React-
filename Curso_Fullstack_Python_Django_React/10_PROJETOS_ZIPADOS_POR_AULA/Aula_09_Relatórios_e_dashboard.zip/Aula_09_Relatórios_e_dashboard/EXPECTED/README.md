# EXPECTED — Aula 09

Este diretório mostra o marco esperado de **dashboard**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 9.
