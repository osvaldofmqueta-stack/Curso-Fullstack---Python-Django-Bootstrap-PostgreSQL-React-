# EXPECTED — Aula 09

Este diretório mostra o marco esperado de **dashboard**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 9.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
