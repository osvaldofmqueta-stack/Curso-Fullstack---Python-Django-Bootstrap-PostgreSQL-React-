from django.db.models import Count
from .models import Categoria

def categorias_com_total():
    return Categoria.objects.annotate(total=Count("produtos"))
