# Transição para a Aula 3

Os produtos e categorias já existem no Admin. Na Aula 3, serão apresentados no navegador com URLs, views e templates.
