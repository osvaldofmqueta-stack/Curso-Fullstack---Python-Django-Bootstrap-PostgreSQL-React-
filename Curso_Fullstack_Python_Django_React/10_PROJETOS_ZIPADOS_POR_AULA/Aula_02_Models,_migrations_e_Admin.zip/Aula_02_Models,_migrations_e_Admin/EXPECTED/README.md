# EXPECTED — Aula 02

Este diretório mostra o marco esperado de **backend com o catálogo de produtos**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 2.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
