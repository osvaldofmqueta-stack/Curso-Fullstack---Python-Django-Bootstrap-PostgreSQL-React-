# EXPECTED — Aula 02

Este diretório mostra o marco esperado de **backend com produtos**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 2.
