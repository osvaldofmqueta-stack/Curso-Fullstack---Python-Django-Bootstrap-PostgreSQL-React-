from django.db import models

class Categoria(models.Model):
    nome = models.CharField(max_length=100, unique=True)

class Produto(models.Model):
    categoria = models.ForeignKey(Categoria, on_delete=models.PROTECT)
    nome = models.CharField(max_length=150)
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)
