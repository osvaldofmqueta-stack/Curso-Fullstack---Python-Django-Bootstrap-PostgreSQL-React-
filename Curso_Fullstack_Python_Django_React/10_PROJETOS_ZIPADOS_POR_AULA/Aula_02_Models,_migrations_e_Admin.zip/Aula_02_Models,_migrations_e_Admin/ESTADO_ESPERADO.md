# Estado esperado — Aula 02

## Marco visual

A aplicação está na fase: **backend com produtos**.

## Estrutura mínima

```text
├── manage.py
├── config/settings.py
├── config/urls.py
├── produtos/models.py
├── requirements.txt
├── .gitignore
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
