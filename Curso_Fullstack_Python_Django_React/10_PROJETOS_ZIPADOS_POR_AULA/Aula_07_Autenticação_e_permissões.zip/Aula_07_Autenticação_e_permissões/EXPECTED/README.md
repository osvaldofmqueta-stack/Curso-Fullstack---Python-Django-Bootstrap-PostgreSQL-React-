# EXPECTED — Aula 07

Este diretório mostra o marco esperado de **contas e permissões**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 7.
