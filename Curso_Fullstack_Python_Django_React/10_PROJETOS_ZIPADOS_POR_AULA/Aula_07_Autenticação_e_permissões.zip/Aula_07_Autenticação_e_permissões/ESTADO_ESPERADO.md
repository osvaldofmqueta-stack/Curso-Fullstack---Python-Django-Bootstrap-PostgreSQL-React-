# Estado esperado — Aula 07

## Marco visual

A aplicação está na fase: **contas e permissões**.

## Estrutura mínima

```text
├── manage.py
├── produtos/forms.py
├── produtos/views.py
├── contas/views.py
├── templates/registration/login.html
├── produtos/tests/test_views.py
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
