# EXPECTED — Aula 11

Este diretório mostra o marco esperado de **ficheiro PDF**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 11.
