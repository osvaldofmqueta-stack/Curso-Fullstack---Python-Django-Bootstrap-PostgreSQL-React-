# EXPECTED — Aula 11

Este diretório mostra o marco esperado de **ficheiro PDF**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 11.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
