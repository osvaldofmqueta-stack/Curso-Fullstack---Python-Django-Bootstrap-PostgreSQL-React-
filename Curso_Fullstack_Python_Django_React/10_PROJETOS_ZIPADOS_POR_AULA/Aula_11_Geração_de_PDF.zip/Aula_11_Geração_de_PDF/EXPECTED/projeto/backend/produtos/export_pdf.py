from django.template.loader import render_to_string
from weasyprint import HTML

def criar_pdf(request, produtos):
    html = render_to_string("produtos/relatorio_pdf.html", {"produtos": produtos})
    return HTML(string=html, base_url=request.build_absolute_uri("/")).write_pdf()
