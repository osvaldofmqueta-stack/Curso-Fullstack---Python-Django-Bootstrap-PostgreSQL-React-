from django.shortcuts import render
from .models import Produto

def lista_produtos(request):
    produtos = Produto.objects.filter(ativo=True)
    return render(request, "produtos/lista.html", {"produtos": produtos})
