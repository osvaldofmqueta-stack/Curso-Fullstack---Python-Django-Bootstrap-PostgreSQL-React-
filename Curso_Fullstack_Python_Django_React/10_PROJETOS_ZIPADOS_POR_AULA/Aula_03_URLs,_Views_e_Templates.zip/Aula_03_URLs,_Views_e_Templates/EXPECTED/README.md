# EXPECTED — Aula 03

Este diretório mostra o marco esperado de **primeira página web**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 3.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
