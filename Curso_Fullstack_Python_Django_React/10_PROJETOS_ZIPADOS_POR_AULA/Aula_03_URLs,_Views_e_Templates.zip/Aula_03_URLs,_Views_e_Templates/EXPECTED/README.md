# EXPECTED — Aula 03

Este diretório mostra o marco esperado de **primeira página web**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 3.
