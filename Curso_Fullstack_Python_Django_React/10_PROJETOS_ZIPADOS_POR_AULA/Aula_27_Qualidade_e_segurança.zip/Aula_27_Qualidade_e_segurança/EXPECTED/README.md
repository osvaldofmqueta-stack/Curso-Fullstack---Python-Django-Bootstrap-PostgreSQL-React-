# EXPECTED — Aula 27

Este diretório mostra o marco esperado de **release confiável**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 27.
