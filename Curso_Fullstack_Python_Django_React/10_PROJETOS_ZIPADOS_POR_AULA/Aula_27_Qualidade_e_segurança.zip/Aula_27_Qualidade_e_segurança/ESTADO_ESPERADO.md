# Estado esperado — Aula 27

## Marco visual

A aplicação está na fase: **release confiável**.

## Estrutura mínima

```text
├── backend/manage.py
├── backend/config/settings.py
├── backend/apps/core/models.py
├── backend/apps/api/serializers.py
├── frontend/src/App.jsx
├── docs/README.md
├── .env.example
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
