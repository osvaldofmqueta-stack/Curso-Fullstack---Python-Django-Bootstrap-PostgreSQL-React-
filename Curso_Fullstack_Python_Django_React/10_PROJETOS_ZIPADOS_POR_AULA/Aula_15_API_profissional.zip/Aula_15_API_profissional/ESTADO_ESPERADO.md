# Estado esperado — Aula 15

## Marco visual

A aplicação está na fase: **API pronta para frontend**.

## Estrutura mínima

```text
├── manage.py
├── config/settings.py
├── produtos/api/serializers.py
├── produtos/api/views.py
├── api/urls.py
├── .env.example
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
