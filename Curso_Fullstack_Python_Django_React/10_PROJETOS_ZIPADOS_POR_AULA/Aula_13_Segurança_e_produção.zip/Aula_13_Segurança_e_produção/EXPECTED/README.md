# EXPECTED — Aula 13

Este diretório mostra o marco esperado de **configuração segura**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 13.
