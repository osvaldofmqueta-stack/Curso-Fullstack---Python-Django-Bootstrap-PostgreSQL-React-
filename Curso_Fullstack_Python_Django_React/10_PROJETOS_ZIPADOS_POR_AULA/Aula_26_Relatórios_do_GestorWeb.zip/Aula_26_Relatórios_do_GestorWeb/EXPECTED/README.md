# EXPECTED — Aula 26

Este diretório mostra o marco esperado de **decisões com dados**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 26.
