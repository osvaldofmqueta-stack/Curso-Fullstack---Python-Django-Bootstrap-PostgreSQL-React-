def resumo_periodo(inicio, fim):
    # centralizar aqui as consultas dos relatórios
    return {"inicio": inicio, "fim": fim}
