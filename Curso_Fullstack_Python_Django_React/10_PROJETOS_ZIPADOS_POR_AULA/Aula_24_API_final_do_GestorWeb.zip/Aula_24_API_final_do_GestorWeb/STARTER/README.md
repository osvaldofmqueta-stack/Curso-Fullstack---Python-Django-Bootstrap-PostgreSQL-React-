# STARTER — Aula 24

Começa aqui. Cria a estrutura indicada na apostila sem abrir a solução esperada antes da tua tentativa.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
