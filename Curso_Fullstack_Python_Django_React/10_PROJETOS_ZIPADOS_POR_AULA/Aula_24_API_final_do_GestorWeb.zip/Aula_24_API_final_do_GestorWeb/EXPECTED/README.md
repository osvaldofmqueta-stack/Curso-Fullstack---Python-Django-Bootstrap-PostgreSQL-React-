# EXPECTED — Aula 24

Este diretório mostra o marco esperado de **API do produto**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 24.
