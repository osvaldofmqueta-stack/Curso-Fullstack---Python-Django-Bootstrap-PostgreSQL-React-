# Aula 25 — Frontend final do GestorWeb

## O que esta pasta representa

Este ZIP é o kit-guia do estado da aplicação depois da Aula 25. Ele acompanha o curso e mostra o ponto de partida e o resultado esperado.

## Objetivo

Construir páginas e fluxos de utilização.

## Resultado esperado

Ao terminar, a aplicação deve ter: **produto utilizável**.

## Como usar

1. Extrai este ZIP para uma pasta de estudo.
2. Lê `ESTADO_ESPERADO.md` e observa `projeto/`.
3. Começa pelo `STARTER/` se quiseres construir sem solução.
4. Usa `EXPECTED/` apenas para comparar depois da tua tentativa.
5. Executa o checklist e regista os erros.

## Importante

O conteúdo `EXPECTED/` é uma referência didática da estrutura e dos exemplos principais da aula. A implementação deve ser construída por ti seguindo a apostila correspondente.

## Fase

07_PROJETO_FINAL_E_DEPLOY

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
