# EXPECTED — Aula 25

Este diretório mostra o marco esperado de **produto utilizável**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 25.
