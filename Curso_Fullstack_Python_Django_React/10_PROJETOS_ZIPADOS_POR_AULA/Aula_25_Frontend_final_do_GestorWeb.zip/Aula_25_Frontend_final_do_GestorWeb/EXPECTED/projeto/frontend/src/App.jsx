export default function App() {
  return <h1>GestorWeb</h1>;
}
