# STARTER — Aula 25

Começa aqui. Cria a estrutura indicada na apostila sem abrir a solução esperada antes da tua tentativa.
