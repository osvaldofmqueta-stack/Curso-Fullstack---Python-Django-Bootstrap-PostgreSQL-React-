# EXPECTED — Aula 08

Este diretório mostra o marco esperado de **qualidade verificável**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 8.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
