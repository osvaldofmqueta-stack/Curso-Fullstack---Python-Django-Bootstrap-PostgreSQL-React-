# EXPECTED — Aula 08

Este diretório mostra o marco esperado de **qualidade verificável**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 8.
