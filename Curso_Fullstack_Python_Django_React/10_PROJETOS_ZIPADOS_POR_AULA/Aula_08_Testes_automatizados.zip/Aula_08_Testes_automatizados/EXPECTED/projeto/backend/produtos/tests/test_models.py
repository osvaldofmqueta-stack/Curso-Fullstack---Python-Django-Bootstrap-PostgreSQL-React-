from django.test import TestCase

class ProdutoTest(TestCase):
    def test_modelo_pode_ser_criado(self):
        self.assertTrue(True)  # substituir pelo teste real da aula
