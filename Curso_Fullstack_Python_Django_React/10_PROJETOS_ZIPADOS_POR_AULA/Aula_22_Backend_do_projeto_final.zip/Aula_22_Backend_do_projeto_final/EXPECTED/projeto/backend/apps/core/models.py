class Cliente(models.Model):
    nome = models.CharField(max_length=160)

class Venda(models.Model):
    cliente = models.ForeignKey(Cliente, on_delete=models.PROTECT)
