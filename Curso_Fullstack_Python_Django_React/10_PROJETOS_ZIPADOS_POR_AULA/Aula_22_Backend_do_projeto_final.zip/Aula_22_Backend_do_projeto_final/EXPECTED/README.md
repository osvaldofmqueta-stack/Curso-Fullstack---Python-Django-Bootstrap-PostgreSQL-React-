# EXPECTED — Aula 22

Este diretório mostra o marco esperado de **domínio do negócio**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 22.
