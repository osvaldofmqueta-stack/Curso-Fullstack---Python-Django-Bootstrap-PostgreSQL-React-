# EXPECTED — Aula 04

Este diretório mostra o marco esperado de **consultas reutilizáveis**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 4.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
