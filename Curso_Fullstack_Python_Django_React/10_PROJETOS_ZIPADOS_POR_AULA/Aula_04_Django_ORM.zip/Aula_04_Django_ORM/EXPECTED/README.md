# EXPECTED — Aula 04

Este diretório mostra o marco esperado de **consultas reutilizáveis**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 4.
