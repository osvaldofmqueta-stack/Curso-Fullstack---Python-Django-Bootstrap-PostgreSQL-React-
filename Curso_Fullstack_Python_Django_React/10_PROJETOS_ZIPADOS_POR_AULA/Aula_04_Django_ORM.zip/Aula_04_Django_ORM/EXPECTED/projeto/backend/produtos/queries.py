from .models import Produto

def produtos_disponiveis():
    return Produto.objects.filter(ativo=True, stock__gt=0).order_by("nome")
