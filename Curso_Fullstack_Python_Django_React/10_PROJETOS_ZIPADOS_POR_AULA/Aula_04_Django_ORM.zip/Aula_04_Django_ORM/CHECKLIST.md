# Checklist

- [ ] Li a Aula 4 e compreendi o objetivo.
- [ ] Criei ou alterei os ficheiros do projeto.
- [ ] Executei a aplicação ou comando indicado.
- [ ] Comparei o resultado com EXPECTED.
- [ ] Registei pelo menos um erro e a solução.
