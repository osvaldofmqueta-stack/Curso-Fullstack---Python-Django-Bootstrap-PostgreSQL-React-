# Estado esperado — Aula 05

## Marco visual

A aplicação está na fase: **interface Bootstrap**.

## Estrutura mínima

```text
├── manage.py
├── config/urls.py
├── produtos/views.py
├── produtos/urls.py
├── templates/base.html
├── templates/produtos/lista.html
├── static/css/app.css
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
