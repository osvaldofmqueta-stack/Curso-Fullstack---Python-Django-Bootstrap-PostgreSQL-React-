# Aula 01 — Primeiro projeto Django

## O que esta pasta representa

Este ZIP é o kit-guia do estado da aplicação depois da Aula 1. Ele acompanha o curso e mostra o ponto de partida e o resultado esperado.

## Objetivo

Criar a base do Catálogo Web, o ambiente virtual e o primeiro servidor Django.

## Resultado esperado

Ao terminar, a aplicação deve ter: **estrutura inicial do Catálogo Web**.

## Como usar

1. Extrai este ZIP para uma pasta de estudo.
2. Lê `ESTADO_ESPERADO.md` e observa `projeto/`.
3. Começa pelo `STARTER/` se quiseres construir sem solução.
4. Usa `EXPECTED/` apenas para comparar depois da tua tentativa.
5. Executa o checklist e regista os erros.

## Importante

O conteúdo `EXPECTED/` é uma referência didática da estrutura e dos exemplos principais da aula. A implementação deve ser construída por ti seguindo a apostila correspondente.

## Fase

01_FUNDAMENTOS_DJANGO

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
