# Estado inicial

Criar o projeto Django conforme a Aula 1.

Resultado esperado: manage.py, config/ e db.sqlite3.
