# Estado inicial

Criar o projeto Django conforme a Aula 1.

Resultado esperado: manage.py, config/ e a base do Catálogo Web preparada para a Aula 2.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
