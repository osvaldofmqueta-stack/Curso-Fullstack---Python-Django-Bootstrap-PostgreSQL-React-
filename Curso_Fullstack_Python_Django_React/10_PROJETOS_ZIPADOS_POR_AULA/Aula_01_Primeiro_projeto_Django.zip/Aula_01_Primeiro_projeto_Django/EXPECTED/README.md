# EXPECTED — Aula 01

Este diretório mostra o marco esperado de **backend inicial**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 1.
