# Estado esperado — Aula 10

## Marco visual

A aplicação está na fase: **ficheiro Excel**.

## Estrutura mínima

```text
├── manage.py
├── produtos/views_dashboard.py
├── produtos/exporters.py
├── templates/produtos/dashboard.html
├── static/css/relatorio.css
```

## Verificação manual

- O resultado da aula aparece na aplicação.
- O fluxo pode ser explicado sem copiar linha por linha.
- O exercício principal foi executado.
- O desafio foi tentado.
