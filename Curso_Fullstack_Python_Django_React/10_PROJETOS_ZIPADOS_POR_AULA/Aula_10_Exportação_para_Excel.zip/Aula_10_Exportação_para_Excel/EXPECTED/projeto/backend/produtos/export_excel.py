from openpyxl import Workbook

def criar_livro(produtos):
    livro = Workbook()
    folha = livro.active
    folha.append(["Nome", "Preço", "Stock"])
    for produto in produtos:
        folha.append([produto.nome, float(produto.preco), produto.stock])
    return livro
