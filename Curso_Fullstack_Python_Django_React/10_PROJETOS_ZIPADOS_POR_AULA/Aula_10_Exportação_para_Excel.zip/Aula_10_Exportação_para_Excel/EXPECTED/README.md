# EXPECTED — Aula 10

Este diretório mostra o marco esperado de **ficheiro Excel**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 10.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
