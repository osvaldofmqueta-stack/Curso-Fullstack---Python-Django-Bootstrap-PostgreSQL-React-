# EXPECTED — Aula 10

Este diretório mostra o marco esperado de **ficheiro Excel**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 10.
