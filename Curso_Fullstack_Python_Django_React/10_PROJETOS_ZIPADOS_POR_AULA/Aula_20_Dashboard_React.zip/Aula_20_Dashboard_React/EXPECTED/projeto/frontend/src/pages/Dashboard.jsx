export default function Dashboard({ resumo }) {
  return <main><h1>Visão do negócio</h1><p>{resumo?.total ?? 0} produtos</p></main>;
}
