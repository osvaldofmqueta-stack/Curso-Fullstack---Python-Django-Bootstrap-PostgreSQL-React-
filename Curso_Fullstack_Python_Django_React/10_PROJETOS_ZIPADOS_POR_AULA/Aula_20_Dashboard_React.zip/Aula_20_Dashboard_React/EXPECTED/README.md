# EXPECTED — Aula 20

Este diretório mostra o marco esperado de **dashboard moderno**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 20.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
