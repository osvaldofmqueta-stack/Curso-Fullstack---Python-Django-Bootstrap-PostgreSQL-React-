# EXPECTED — Aula 28

Este diretório mostra o marco esperado de **GestorWeb publicado**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 28.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
