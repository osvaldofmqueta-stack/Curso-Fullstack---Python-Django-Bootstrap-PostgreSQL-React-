# EXPECTED — Aula 28

Este diretório mostra o marco esperado de **GestorWeb publicado**. Usa-o depois de tentares a solução.

A referência completa está na apostila Aula 28.
