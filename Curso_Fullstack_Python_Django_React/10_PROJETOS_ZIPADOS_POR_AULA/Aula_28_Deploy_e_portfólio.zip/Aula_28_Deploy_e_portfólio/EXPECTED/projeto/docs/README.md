# GestorWeb

Como executar, arquitetura, variáveis, demonstração e decisões do projeto.

---

**Elaborado por Osvaldo Queta — Engenheiro Informático desde 2015 — Programador Sénior com mais de 8 anos de experiência**
