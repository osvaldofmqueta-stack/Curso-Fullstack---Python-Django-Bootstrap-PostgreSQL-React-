# GestorWeb

Como executar, arquitetura, variáveis, demonstração e decisões do projeto.
